import Home from './pages/Index';

function App() {
  return (
    <Home />
  );
}

export default App;
