function Header() {
	return <header>
		<ul>
			<li>
				<button>Home</button>
			</li>
			<li>
				<button>About</button>
			</li>
			<li>
				<button>Portfolio</button>
			</li>
		</ul>
	</header>
}

export default Header;